
import { GoogleGenAI, Type } from "@google/genai";
import { Language } from "../i18n";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface NewsItem {
  title: string;
  source: string;
  url: string;
  time: string;
  summary: string;
}

const langNames = {
  pt: 'Portuguese (Brazil)',
  en: 'English (US)',
  es: 'Spanish (Spain)',
  zh: 'Mandarin (China)'
};

export const fetchMarketNews = async (query: string, lang: Language): Promise<NewsItem[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Fetch and summarize the top 5 most recent and relevant market news articles for "${query}". 
      Return a list of news items. For each item provide: title, source name, URL, and a very brief 1-sentence summary.
      IMPORTANT: The response MUST be entirely in ${langNames[lang]}.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              source: { type: Type.STRING },
              url: { type: Type.STRING },
              time: { type: Type.STRING, description: "e.g., 2 hours ago" },
              summary: { type: Type.STRING }
            },
            required: ["title", "source", "url", "summary"]
          }
        }
      },
    });

    try {
      const news = JSON.parse(response.text);
      return news;
    } catch (e) {
      console.error("JSON Parse error for news", e);
      return [];
    }
  } catch (error) {
    console.error("Gemini News Error:", error);
    return [];
  }
};
