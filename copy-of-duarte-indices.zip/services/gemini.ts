
import { GoogleGenAI } from "@google/genai";
import { AnalysisResult } from "../types";
import { Language } from "../i18n";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const langNames = {
  pt: 'Português (Brasil)',
  en: 'English (US)',
  es: 'Español (España)',
  zh: 'Mandarin (China)'
};

export const analyzeMarketAsset = async (symbol: string, name: string, lang: Language = 'en'): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `VOCÊ É UM ANALISTA SENIOR DE DAY TRADE. 
      Analise o ativo ${name} (${symbol}) para o dia de hoje.
      
      REGRAS OBRIGATÓRIAS:
      1. IDIOMA: Responda TODO o texto estritamente em ${langNames[lang]}. Não use palavras em inglês se o idioma for diferente.
      2. FOCO: Day trade, volatilidade intraday, volume e notícias de impacto imediato.
      
      ESTRUTURA DA RESPOSTA:
      - RESUMO: Situação atual do mercado e notícias recentes (Grounding).
      - TENDÊNCIA INTRADAY: Se o viés é de alta, baixa ou lateralização para as próximas horas.
      - ESTRATÉGIA: Sugestão de entrada (Long/Short/Aguardar) com justificativa técnica.
      - NÍVEIS CHAVE: Liste 2 suportes e 2 resistências numéricos baseados no preço atual.
      
      ESTILO: Profissional, direto, focado em risco/retorno.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "Análise indisponível no momento.";
    
    const metadata = response.candidates?.[0]?.groundingMetadata;
    const chunks = metadata?.groundingChunks || [];
    const supports = metadata?.groundingSupports || [];

    const sourcesMap = new Map<number, { title: string, url: string, snippets: string[] }>();

    chunks.forEach((chunk: any, index: number) => {
      if (chunk.web) {
        sourcesMap.set(index, {
          title: chunk.web.title || "Fonte de Mercado",
          url: chunk.web.uri || "",
          snippets: []
        });
      }
    });

    supports.forEach((support: any) => {
      const segmentText = support.segment?.text?.trim();
      if (segmentText) {
        support.groundingChunkIndices?.forEach((idx: number) => {
          const source = sourcesMap.get(idx);
          if (source) {
            if (!source.snippets.some(s => s.toLowerCase() === segmentText.toLowerCase())) {
              source.snippets.push(segmentText);
            }
          }
        });
      }
    });

    const sources = Array.from(sourcesMap.values()).map(s => ({
      title: s.title,
      url: s.url,
      snippet: s.snippets.join(' ').substring(0, 180) + (s.snippets.join(' ').length > 180 ? '...' : '')
    })).filter(s => s.url);

    const lowerText = text.toLowerCase();
    let sentiment: 'Bullish' | 'Bearish' | 'Neutral' = 'Neutral';
    
    // Multi-language sentiment detection
    const bullishKeywords = ['alta', 'bullish', 'otimista', 'comprar', 'buy', 'compra', '上涨', 'long'];
    const bearishKeywords = ['baixa', 'bearish', 'pessimista', 'vender', 'sell', 'venda', '下跌', 'short'];

    if (bullishKeywords.some(k => lowerText.includes(k))) {
      sentiment = 'Bullish';
    } else if (bearishKeywords.some(k => lowerText.includes(k))) {
      sentiment = 'Bearish';
    }

    return {
      sentiment,
      summary: text,
      keyLevels: {
        support: [0, 0], // Prices will be extracted/referenced from text by the user usually, using placeholders here
        resistance: [0, 0]
      },
      recommendation: sentiment === 'Bullish' ? 'Long' : sentiment === 'Bearish' ? 'Short' : 'Wait',
      sources
    };
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
